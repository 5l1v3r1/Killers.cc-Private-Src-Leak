class Skins
{
public:
    
    int knifeT      = WEAPON_KNIFE_BUTTERFLY;
    int knifeCT     = WEAPON_KNIFE_M9_BAYONET;
    int TknifeID    = 561;
    int CTknifeID   = 561;
    int TknifeSeed  = 0;
    int CTknfieSeed = 0;
    
    int gloveT      = GLOVE_MOTORCYCLE;
    int gloveCT     = GLOVE_MOTORCYCLE;
    int TgloveID    = 10049;
    int CTgloveID   = 10049;
    
    int galil   = 661;
    int famas   = 529;
    int ak      = 675;
    int a4      = 309;
    int a1      = 430;
    int scout   = 222;
    int sg      = 259;
    int aug     = 601;
    int awp     = 259;
    int g3      = 511;
    int scar    = 232;
    
    int glock   = 353;
    int usp     = 504;
    int p2000   = 591;
    int dual    = 0;
    int p250    = 668;
    int tec9    = 671;
    int five7   = 44;
    int cz      = 350;
    int deagle  = 232;
    int r8      = 12;
    
    int mac10   = 589;
    int mp9     = 33;
    int mp7     = 696;
    int ump     = 436;
    int p90     = 169;
    int bizon   = 203;
    
    int nova    = 537;
    int sawed   = 638;
    int mag7    = 666;
    int xm      = 654;
    int m249    = 648;
    int negev   = 483;
    
    int galil_Seed   = 0;
    int famas_Seed   = 0;
    int ak_Seed      = 0;
    int a4_Seed      = 0;
    int a1_Seed      = 0;
    int scout_Seed   = 0;
    int sg_Seed      = 0;
    int aug_Seed     = 0;
    int awp_Seed     = 0;
    int g3_Seed      = 0;
    int scar_Seed    = 0;
    
    int glock_Seed   = 0;
    int usp_Seed     = 0;
    int p2000_Seed   = 0;
    int dual_Seed    = 0;
    int p250_Seed    = 0;
    int tec9_Seed    = 0;
    int five7_Seed   = 0;
    int cz_Seed      = 0;
    int deagle_Seed  = 0;
    int r8_Seed      = 0;
    
    int mac10_Seed   = 0;
    int mp9_Seed     = 0;
    int mp7_Seed     = 0;
    int ump_Seed     = 0;
    int p90_Seed     = 0;
    int bizon_Seed   = 0;
    
    int nova_Seed    = 0;
    int sawed_Seed   = 0;
    int mag7_Seed    = 0;
    int xm_Seed      = 0;
    int m249_Seed    = 0;
    int negev_Seed   = 0;
};


extern Skins skin;
