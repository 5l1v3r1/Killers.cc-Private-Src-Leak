#include "main.h"

cVariables vars;
Corrections gCorrections[64];
