#include "main.h"

// GameEventVMT
#define FireGameEventIndex 11
// ClientVMT
#define FrameStageIndex 37
#define FireEventIndex 9

/*
* VMT End
*/
