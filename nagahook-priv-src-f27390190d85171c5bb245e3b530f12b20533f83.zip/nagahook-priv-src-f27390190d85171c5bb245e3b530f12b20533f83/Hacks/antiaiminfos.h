#include "hooks.h"
#include "esp.h"
#include "main.h"
void AntiAimInfo(CUserCmd* cmd, C_BaseEntity* local, C_BaseCombatWeapon* weapon, bool& bPacket);
