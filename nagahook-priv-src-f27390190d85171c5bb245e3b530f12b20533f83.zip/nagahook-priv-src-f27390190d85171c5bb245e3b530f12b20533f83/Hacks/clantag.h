#include "main.h"
void clan_tag();
