//
//  snipercrosshair.hpp
//  vHook
//
//  Created by Timothy Dillan on 11/8/19.
//  Copyright © 2019 ViKiNG. All rights reserved.
//
#include "../main.h"
namespace SniperCrosshair
{
    
    //Hooks
    void Paint();
};
