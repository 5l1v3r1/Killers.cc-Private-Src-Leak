#pragma once

#include "../main.h"
#include <list>

std::list<int> GetObservervators(int playerId);
void Spectatorlist();
