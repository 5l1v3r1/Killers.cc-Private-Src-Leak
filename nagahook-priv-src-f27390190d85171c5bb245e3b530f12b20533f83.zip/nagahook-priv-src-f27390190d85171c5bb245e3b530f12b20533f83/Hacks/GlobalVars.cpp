//
//  GlobalVars.cpp
//  vHook
//
//  Created by Timothy Dillan on 31/10/19.
//  Copyright © 2019 ViKiNG. All rights reserved.
//

#include "../main.h"

namespace g
{
    bool           Shot[65];
    bool           Hit[65];
    int            MissedShots[65];

}
