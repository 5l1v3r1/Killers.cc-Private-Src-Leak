#include "autowall.h"
#include <vector>
#include <cstdint>
#include <random>
#include "../SDK/Others.h"

namespace Resolver
{
    
    //Hooks
    void FrameStageNotify(ClientFrameStage_t stage);
    void OnCreateMove();
}


