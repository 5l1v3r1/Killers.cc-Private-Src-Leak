#include "main.h"

void DoBhop(CUserCmd* cmd, C_BaseEntity* local);
void AutoStrafeCreateMove(CUserCmd* cmd);
void CirlceStrafe(C_BaseEntity *localPlayer, CUserCmd *cmd, Vector &oldAngles);
