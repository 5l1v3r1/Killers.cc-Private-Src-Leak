#include "main.h"

void rCrosshair(C_BaseEntity* local);
void DrawScope(C_BaseEntity* local);
void sCrosshair(C_BaseEntity* local);
void manualaa(C_BaseEntity* Local, int keynum);

void players_behind();
void DrawFakeAngle(C_BaseEntity* local);
