#include "../main.h"

void DoTrigger(CUserCmd *Cmd, C_BaseCombatWeapon* activeWeapon);
