namespace g
{
    extern bool           Shot[65];
    extern bool           Hit[65];
}
