#include "main.h"
#include <deque>
void DrawOtherESP();
void DrawPlayerESP();

void DrawAngles(C_BaseEntity* local);
void DrawSpread(C_BaseEntity* local);
void pwnmymenu();

