#include "../main.h"

void asuswalls(ClientFrameStage_t stage);

void NightMode();
void FullBright();
void InverseRagdoll();
void ViewmodelHVH();
void GrenadeTrajectory();
