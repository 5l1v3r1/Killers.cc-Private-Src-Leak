#pragma once
#include "../main.h"
namespace Autoblock
{
    //Hooks
    void CreateMove(CUserCmd* cmd);
}
