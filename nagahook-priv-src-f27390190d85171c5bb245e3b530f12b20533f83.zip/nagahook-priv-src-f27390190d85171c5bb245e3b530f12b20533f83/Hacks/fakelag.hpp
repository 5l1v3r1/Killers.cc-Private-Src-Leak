/*
 *  movement.h
 */
#pragma once
#include "main.h"

    
void FakeLag(CUserCmd* cmd);
    
