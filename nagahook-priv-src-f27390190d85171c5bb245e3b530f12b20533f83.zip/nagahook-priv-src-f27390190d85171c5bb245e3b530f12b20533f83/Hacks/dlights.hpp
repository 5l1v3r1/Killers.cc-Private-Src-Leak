#pragma once

namespace Dlights
{
    //Hooks
    void Paint();
}
