#include "../main.h"
namespace Airstuck
{
    //Hooks
    void CreateMove(CUserCmd* cmd);
}
