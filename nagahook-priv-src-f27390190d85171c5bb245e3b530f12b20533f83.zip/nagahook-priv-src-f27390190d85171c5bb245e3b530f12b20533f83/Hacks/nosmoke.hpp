/*
 *  misc.h
 */
#include "../main.h"


void remove_smoke(ClientFrameStage_t stage);
