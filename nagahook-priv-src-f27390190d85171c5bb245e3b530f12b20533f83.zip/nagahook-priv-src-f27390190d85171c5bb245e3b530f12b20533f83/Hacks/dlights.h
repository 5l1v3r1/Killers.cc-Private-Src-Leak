#include "main.h"

auto DLights() -> void;
