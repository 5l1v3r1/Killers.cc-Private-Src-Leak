//
//  PredictionSystem.hpp
//  Breathless
//
//  Created by Paul on 28/7/19.
//  Copyright © 2019 syn. All rights reserved.
//

#include <stdio.h>

#include "main.h"

void StartPrediction(CUserCmd* cmd);
void EndPrediction();
