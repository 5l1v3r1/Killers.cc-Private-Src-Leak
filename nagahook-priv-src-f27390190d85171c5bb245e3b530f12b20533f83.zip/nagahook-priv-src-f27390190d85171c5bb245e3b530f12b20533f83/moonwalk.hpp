//
//  moonwalk.hpp
//  vHook
//
//  Created by Warlauke on 10/25/17.
//  Copyright © 2017 ViKiNG. All rights reserved.
//
#include "main.h"

void Moonwalk(CUserCmd* cmd);
