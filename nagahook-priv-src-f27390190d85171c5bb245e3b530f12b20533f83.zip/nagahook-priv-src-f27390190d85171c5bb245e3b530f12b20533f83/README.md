# killers.cc
A better Version of breathless maybe ;^)

## Why is this existing and not on the face.us repo?
The face.us repository got deleted by faithful (CreditCode) the creator, long live the original fork

# Credits

Raizo (updating breathless)

ViKiNG (Making Barbossa)

-X/Syn (Making breathless and everything in life)
Akalisch (NetVarManager/PatternScanner)

Pwned (Menu & Sorting Everything)

Warlauke (Barbossa & Noriaela)

CreditCode (cooperative and deleted the face.us repository) 

Nagatoro|单独/Mike (The idea to create the paste, searching for sources to paste from, recommendations)

Gael (For cooperatively testing, giving feedback, and is always ready to help 24/7/365)

Giraffe/George (for hvhing with gael to test it out lmao + he's gay)

Tim (Making the paste and adding any feature we want for free cuz he's a fat fuck)


MAKE BREATHLESS GREAT AGAIN

