#pragma once



void DuckCool(CUserCmd* cmd);
    


