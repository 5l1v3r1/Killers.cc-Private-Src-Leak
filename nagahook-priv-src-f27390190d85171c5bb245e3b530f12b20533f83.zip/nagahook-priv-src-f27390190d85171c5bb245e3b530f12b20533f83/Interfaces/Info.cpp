/*
 
 This was on my discord a while ago viking uploaded it to the discord after his site went down i'm grateful viking made this.
 PS: a bit of the code that I added is from aimtux/forks
 
 Vange.me

 How to inject the cheat
 

  Launch CSGO
  Open terminal
  Extract vange.me folder and put it on your desktop
  Type "cd Desktop/vange.me" KOPY AND PASTE
  Then KOPY AND PASTE THIS AS WELL "sudo ./vange.me csgo_osx64 libvHook.dylib" and enter
  Type your MAC password
  Wait for the cheat to inject
  Tab back into csgo
  Open the menu with Left Alt or Ins
  Enjoy hacking and try not get banned!

 
 - Bellez
  ----------------------------------------------------------------------------------------------------------------------
 This is my version of Barbossa, it is more efficient then barbossa since it is the best pasta ever
 
 - Warlauke/sonicrules11
 ----------------------------------------------------------------------------------------------------------------------
 
 Hello boys and girls.
 This is the last release of the mac cheat that i will be working on. That's right, i will quit working on mac cheat from now on
 and focus more on my windows cheat.
 This project has been alot of fun and i wan't to thank all who have been helping me making this possible.
 
 Credits to
 w s
 viking
 trinialol (for making a tutorial on how to compile it)
 McSwaggens (for his linux base and much other things)
 
 ----------------------------
 See you guys around!
 
 Regards:
 ViKiNG.
 ----------------------------
 
*/
