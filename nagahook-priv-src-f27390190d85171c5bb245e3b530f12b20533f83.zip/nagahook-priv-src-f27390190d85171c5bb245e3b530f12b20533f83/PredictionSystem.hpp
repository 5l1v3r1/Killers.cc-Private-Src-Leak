//
//  PredictionSystem.hpp
//  Breathless
//
//  Created by Paul on 28/7/19.
//  Copyright © 2019 syn. All rights reserved.
//

#ifndef PredictionSystem_hpp
#define PredictionSystem_hpp

#include <stdio.h>

#endif /* PredictionSystem_hpp */

#include "main.h"
#include "Utils/checksum_md5.h"
void StartPrediction(CUserCmd* cmd);
void EndPrediction();
